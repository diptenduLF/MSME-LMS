
 
    function onload_click() {
          
	
		dwr.engine.beginBatch();
		NoticePOJO.setNoticeHead(function(data) {
			setValue('headingContent',data);
		});
	 
		NoticePOJO.setNoticeBody(function(data) {
			setValue('noticeBodyContent',data);
 		});
		  
		 
		NoticePOJO.setNoticePostedBy(function(data) {
			setValue('postedByContent',data);
		});
		NoticePOJO.setNoticePostedOn(function(data) {
			setValue('postedOnContent',data);
		});
		NoticePOJO.setAttachFileName(function(data) {
 			
			if(data=="")
			{}
			else{
			setValue('attachmentContent',data);
			}
		});

		dwr.engine.endBatch();
	
	  };
	  
  function done_onclick() {
		  window.close();
	  };
	  
	  
