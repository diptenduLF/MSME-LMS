	var unitIndex = 1;
    var rowId = 0;

     function attach_onclick() {
     	var fileupload=getValue('fileupload');
		     ForumUtil.ShowAttachment(fileupload,function(data) {
			     setValue('step3',data);
		     });	
     }
     function validate() {
	     var i=getValue('fileupload');
	     if(!(fnCheckNull(i,"File Name"))){
		     document.getElementById('fileupload').setfocus();
		     return false;
	     }
	     return true;
     }
     function done_onclick(){
	     var parent="null";
	     if(parent=="null"){
		     history.go(-1);
	     }
	     else {
		     history.go(-1);
	     }
     }
     function fnCheckNull(astrFieldValue,astrFieldName)
     {
	
	     if (fnStripSpaces(astrFieldValue) == "") 
	     {
		     alert("Please enter "+astrFieldName+".");
		     return false;
	     }
	     else 
	     {
		     return true;
	     }	
     }

     function fnStripSpaces (astrString)  
     {		      
	     var astrOutString;
	     var astrTempChar;
	     astrOutString="";
	     for ( Count=0 ; Count < astrString.length ; Count++ )  
	     {
		     astrTempChar=astrString.substring (Count, Count+1);
		     if ( astrTempChar != " " )
		     astrOutString=astrOutString+astrTempChar;
	     }
	     return (astrOutString);
     }

     function onload_click(){
	     ForumUtil.ShowAttachment(click_onload);
	     function click_onload(data) {
		     setValue('step3',data);
	     }
     }   
