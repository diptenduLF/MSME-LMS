
			
			/////////////////////////  jayanta /////////////////////////////////
			function onload_onclick() {
	 			
				NoticePOJO.getNotice(function(data) {
					
					setValue('portalgrid',data);
				});
				
			}
 
 
			function lunchNotice(strnotice_id)
			{
				
				NoticePOJO.setSessionNoticeId(strnotice_id,function(data) {
				//	setValue('CourseHome',data);
					
				});
		 	 
	 
	 
				var browserName = navigator.appName;
				var browserVersion = parseInt(navigator.appVersion);
				var browser;
				if(browserName == 'Microsoft Internet Explorer' && browserVersion >=4){
					browser='ie4up';
				}
				else {
					browser='mf';
				}
				
	 
	
	 
		
				var n = strnotice_id;
				
				window.open('./interfaceenginev2.PortalServlet?IID=LearnityNoticeBoardview',"LearnityNoticeBoardview","width=600,height=540,status=yes,scrollbars=no,resizable=yes,toolbar=no,menubar=no");
				
			}
 
 
 
			function AddNewNotice()
			{
				
				var browserName = navigator.appName;
				var browserVersion = parseInt(navigator.appVersion);
				var browser;
				if(browserName == 'Microsoft Internet Explorer' && browserVersion >=4){
					browser='ie4up';
				}
				else {
					browser='mf';
				}
 
				//document.LearnityPortalform.action="./interfaceengine.PortalServlet?IID=LearnityNoticeBoard";
				window.open('./interfaceenginev2.PortalServlet?IID=LearnityNoticeBoard',"LearnityNoticeBoard","width=600,height=540,status=yes,scrollbars=no,resizable=yes,toolbar=no,menubar=no");
				  
			}
 
 
			///////////////////////// end jayanta /////////////////////////////////////////////x