function onload_click(){
	
	ladminTree.getUserInfo(function(data){
		
		setValue('FNamedata',data[9]);
		setValue('MNamedata',data[10]);	
		setValue('LNamedata',data[1]);	
		setValue('Agedata',data[3]);	
		setValue('Experiencedata',data[5]);	
		setValue('EduQuilidata',data[4]);	
		setValue('Emaildata',data[12]);
		setValue('Genderdate',data[2]);
// 		setValue('QuestionPreferreddate',data[6]);	
// 		setValue('MediaPreferreddata',data[7]);	
		setValue('AccountStatusdata',data[13]);	
		setValue('PermitSelfRegistrationdata',data[14]);
		setValue('UserIddata',data[0]);	
		document.getElementById('UserIddata').disabled=true;
		document.getElementById('Emaildata').tabIndex=8;
		document.getElementById('Genderdate').tabIndex="7";
// 		document.getElementById('QuestionPreferreddate').tabIndex="9";
// 		document.getElementById('MediaPreferreddata').tabIndex="10";
		document.getElementById('AccountStatusdata').tabIndex="11";
		document.getElementById('PermitSelfRegistrationdata').tabIndex="12";
			
			
		
	});
	ladminTree.getPortalUserPhoto(function(data){
		setValue('userimagelabel',data);
	});	
	

}

function Update_user() {
	var validate = true;
	var FNamedata = getValue("FNamedata");
	var MNamedata = getValue("MNamedata");
	
	var LNamedata = getValue("LNamedata");
	var Agedata = getValue("Agedata");
	
	var Experiencedata = getValue("Experiencedata");
	var EduQuilidata = getValue("EduQuilidata");
	
	var Emaildata = getValue("Emaildata");
	var Genderdate = getValue("Genderdate");
	
	
	
	var QuestionPreferreddate = 'Y';
	var MediaPreferreddata = 'Video';
	
	var AccountStatusdata = getValue("AccountStatusdata");
	var PermitSelfRegistrationdata = getValue("PermitSelfRegistrationdata");
	 
	

			ladminTree.ModifyUser(FNamedata,MNamedata,LNamedata,Agedata,Experiencedata,EduQuilidata,Emaildata,Genderdate,QuestionPreferreddate,MediaPreferreddata,AccountStatusdata,PermitSelfRegistrationdata,
			          function(){alert("Successfully Updated User Information");}
			    );
			
} 



function imageupload_onclick(){
	
	
	var file1=document.getElementById("userimage").value;
	if(file1)
	{
		var file = getValue('userimage');
		ladminTree.PortalUserImageUpload(file,function() {
			ladminTree.getPortalUserPhoto(function(data){
				setValue('userimagelabel',data);
				alert("Successfully Uploaded Photo");
			});
		});
	}
	else
	{
		alert('Please browse a file');
	}

}

