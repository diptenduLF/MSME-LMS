
 
    function onload_click() {
          
	
		dwr.engine.beginBatch();
		NoticePOJO.setNoticeHead(function(data) {
			setValue('noticeheadingdata',data);
		});
	 
		NoticePOJO.setNoticeBody(function(data) {
			setValue('noticebodydata',data);
 		});
		  
		 
		NoticePOJO.setNoticePostedBy(function(data) {
			setValue('Postedbyheadingdata',data);
		});
		NoticePOJO.setNoticePostedOn(function(data) {
			setValue('PostedOnheadingdata',data);
		});
		NoticePOJO.setAttachFileName(function(data) {
 			
			if(data=="")
			{}
			else{
			setValue('attachfileslink',data);
			}
		});

		dwr.engine.endBatch();
	
	  };
	  
  function done_onclick() {
		  window.close();
	  };
	  
	  
