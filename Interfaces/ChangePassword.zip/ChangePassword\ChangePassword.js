function onload_click(){
	
	Portal.returnUserId(function(data){
		setValue('UserIddata',data);		
	});
	
	document.getElementById('UserIddata').disabled=true;
}


function change_password() {
	var NewPassworddata = getValue("NewPassworddata");
	var OldPassworddata = getValue("OldPassworddata");
	var RetypePassworddata = getValue("RetypePassworddata");
	var pass_length = NewPassworddata.length;
	
	
	if((OldPassworddata=="null") || (OldPassworddata==""))
	{
		alert('Please enter old password');
		return false;
	}
	else if((NewPassworddata=="null") || (NewPassworddata==""))
	{
		alert('Please enter new password');
		return false;
	}
	else if(pass_length<6)
	{
		alert('Password should be minimum 6 characters');
		return false;
	}
	else if((RetypePassworddata=="null") || (RetypePassworddata==""))
	{
		alert('Please retype new password');
		return false;
	}
	else if(NewPassworddata!=RetypePassworddata)
	{
		alert('Retype password does not match with new password');
		return false;
	}
	else
	{
		Portal.updatePassword(OldPassworddata,NewPassworddata,RetypePassworddata,function(data){
	
			if(data=="no")
			{
				alert("Old Password is wrong. Please supply correct password");
			}
			else
			{
				data="Password successfully changed";
				setValue('mess',data);
			
			}
		
		});	
	}
			
} 


