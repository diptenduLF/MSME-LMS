function onload_click(){
	
	Portal.returnUserId(function(data){
		setValue('UserIddata',data);	
		changePasswordForm_Select();
	});
	
	document.getElementById('UserIddata').disabled=true;
	
}

function submitForm(){
	/*var NewPassworddata = getValue("NewPassworddata");
	var OldPassworddata = getValue("OldPassworddata");
	var RetypePassworddata = getValue("RetypePassworddata");
	Portal.updatePassword(OldPassworddata,NewPassworddata,RetypePassworddata,function(data){
		
		if(data=="no")
		{
			alert("Old Password is wrong. Please supply correct password");
		}
		else
		{
			data="Password successfully changed";
			setValue('mess',data);
		
		}
	
	});	*/
	changePasswordForm_Modify();
	
}



