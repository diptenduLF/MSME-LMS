
$(document).ready(function(){
	$("#replysubject").before("Subject ");
	
	ForumUtil.getReplySubject(showSubject);
		
	function createTextCombo(data) {
		setValue('textcolordropdown',data);
	}
	
	function createFontCombo(data) {
		setValue('fontdropdown',data);
	}
	
	function showSubject(data) {
		setValue('replysubject',data);
	}
	
	ForumUtil.ShowAttachment(function(data) {
		setValue('attachment',data);
	});
	
	$("#replyboldbutton").html("<input class=\"sbutton\" style=\"FONT-WEIGHT: bold; FONT-SIZE:12px; COLOR:white; WIDTH: 70px; BACKGROUND-COLOR: red; -MOZ-BORDER-RADIUS: 10px; border-width:1px; border-style:solid; border-color:black; cursor:pointer\" accesskey=\"b\" onclick=\"set_style(0)\" type=\"button\" value=\" B \" name=\"addstyle0\" />");
	$("#italicsbuttonbutton").html("<input class=\"sbutton\" style=\"FONT-WEIGHT: bold; FONT-SIZE:12px; WIDTH: 70px; COLOR:white; FONT-STYLE: italic; BACKGROUND-COLOR: red; -MOZ-BORDER-RADIUS: 10px; border-width:1px; border-style:solid; border-color:black; cursor:pointer\" accesskey=\"i\" onclick=\"set_style(2)\" type=\"button\" value=\" I \" name=\"addstyle2\" /> ");
	$("#underlinebuttonbutton").html("<input class=\"sbutton\" style=\"FONT-WEIGHT: bold; FONT-SIZE:12px; WIDTH: 70px; COLOR:white; TEXT-DECORATION: underline; BACKGROUND-COLOR: red; -MOZ-BORDER-RADIUS: 10px; border-width:1px; border-style:solid; border-color:black; cursor:pointer\" accesskey=\"u\" onclick=\"set_style(4)\" type=\"button\" value=\" U \" name=\"addstyle4\" /> ");
	$("#quotebuttonbutton").html("<input class=\"sbutton\" style=\"FONT-WEIGHT: bold; FONT-SIZE:12px; WIDTH: 70px; COLOR:white; BACKGROUND-COLOR: red; -MOZ-BORDER-RADIUS: 10px; border-width:1px; border-style:solid; border-color:black; cursor:pointer\" accesskey=\"q\" onclick=\"set_style(6)\" type=\"button\" value=\" Quote \" name=\"addstyle6\" /> ");
	$("#codebuttonbutton").html("<input class=\"sbutton\" style=\"FONT-WEIGHT: bold; FONT-SIZE:12px; WIDTH: 70px; COLOR:white; BACKGROUND-COLOR: red; -MOZ-BORDER-RADIUS: 10px; border-width:1px; border-style:solid; border-color:black; cursor:pointer\" accesskey=\"c\" onclick=\"set_style(8)\" type=\"button\" value=\" Code \" name=\"addstyle8\" /> ");
	$("#listbuttonbutton").html("<input class=\"sbutton\" style=\"FONT-WEIGHT: bold; FONT-SIZE:12px; WIDTH: 70px; COLOR:white; BACKGROUND-COLOR: red; -MOZ-BORDER-RADIUS: 10px; border-width:1px; border-style:solid; border-color:black; cursor:pointer\" accesskey=\"l\" onclick=\"set_style(10)\" type=\"button\" value=\" List \" name=\"addstyle10\" /> ");
	$("#imagebuttonbutton").html("<input class=\"sbutton\" style=\"FONT-WEIGHT: bold; FONT-SIZE:12px; WIDTH: 70px; COLOR:white; BACKGROUND-COLOR: red; -MOZ-BORDER-RADIUS: 10px; border-width:1px; border-style:solid; border-color:black; cursor:pointer\" accesskey=\"l\" onclick=\"set_style(12)\" type=\"button\" value=\" Img \" name=\"addstyle12\" /> ");
	$("#urlbuttonbutton").html("<input class=\"sbutton\" style=\"FONT-WEIGHT: bold; FONT-SIZE:12px; WIDTH: 70px; COLOR:white; BACKGROUND-COLOR: red; -MOZ-BORDER-RADIUS: 10px; border-width:1px; border-style:solid; border-color:black; cursor:pointer\" accesskey=\"l\" onclick=\"set_style(14)\" type=\"button\" value=\" Url \" name=\"addstyle14\" /> ");
	
	$("#textarea").replaceWith("<textarea class=\"post\" onkeyup=\"storeCaret(this);\"  onclick=\"storeCaret(this);\" tabindex=\"3\" name=\"textarea\" rows=\"14\" wrap=\"virtual\" cols=\"70\" onselect=\"storeCaret(this);\"></textarea>");
	$("#smily1").click(function (){emoticon('1');});
	$("#smily2").click(function (){emoticon('2');});
	$("#smily3").click(function (){emoticon('3');});
	$("#smily4").click(function (){emoticon('4');});
	$("#smily5").click(function (){emoticon('5');});
	$("#smily6").click(function (){emoticon('6');});
	$("#smily7").click(function (){emoticon('7');});
	$("#smily8").click(function (){emoticon('8');});
	$("#smily9").click(function (){emoticon('9');});
	$("#smily10").click(function (){emoticon('10');});
	$("#smily11").click(function (){emoticon('11');});
	$("#smily12").click(function (){emoticon('12');});
	$("#smily13").click(function (){emoticon('13');});
	$("#smily14").click(function (){emoticon('14');});
	$("#smily15").click(function (){emoticon('15');});
	$("#smily16").click(function (){emoticon('16');});
	$("#smily17").click(function (){emoticon('17');});
	$("#smily18").click(function (){emoticon('18');});
	$("#smily19").click(function (){emoticon('19');});
	$("#smily20").click(function (){emoticon('20');});

});

function emote(sm)
{
	alert(sm);
}

function emoticon(n){
	var message=getValue('bodytextarea');
	if (document.getElementById('bodytextarea').createTextRange && document.getElementById('bodytextarea').caretPos) {
		var caretPos = document.getElementById('bodytextarea').caretPos;
	caretPos.text = caretPos.text.charAt(caretPos.text.length - 1) == ' ' ? add_smily(n) + ' ' :add_smily(n);
	document.getElementById('bodytextarea').focus();
	} else {
	message=message+' '+add_smily(n);
	setValue('bodytextarea',message);
	document.getElementById('bodytextarea').focus();
	}
}
	
function add_smily(n){
	var smily="";
	
	if(n==1)
	smily="<img src=./interfaceenginev2.ResourceImage?resource_id=smily1&interface_id=thread>";
	if(n==2)
	smily="<img src=./interfaceenginev2.ResourceImage?resource_id=smily2&interface_id=thread>";
	if(n==3)
	smily="<img src=./interfaceenginev2.ResourceImage?resource_id=smily3&interface_id=thread>";
	if(n==4)
	smily="<img src=./interfaceenginev2.ResourceImage?resource_id=smily4&interface_id=thread>";
	if(n==5)
	smily="<img src=./interfaceenginev2.ResourceImage?resource_id=smily5&interface_id=thread>";
	if(n==6)
	smily="<img src=./interfaceenginev2.ResourceImage?resource_id=smily6&interface_id=thread>";
	if(n==7)
	smily="<img src=./interfaceenginev2.ResourceImage?resource_id=smily7&interface_id=thread>";
	if(n==8)
	smily="<img src=./interfaceenginev2.ResourceImage?resource_id=smily8&interface_id=thread>";
	if(n==9)
	smily="<img src=./interfaceenginev2.ResourceImage?resource_id=smily9&interface_id=thread>";
	if(n==10)
	smily="<img src=./interfaceenginev2.ResourceImage?resource_id=smily10&interface_id=thread>";
	if(n==11)
	smily="<img src=./interfaceenginev2.ResourceImage?resource_id=smily11&interface_id=thread>";
	if(n==12)
	smily="<img src=./interfaceenginev2.ResourceImage?resource_id=smily12&interface_id=thread>";
	if(n==13)
	smily="<img src=./interfaceenginev2.ResourceImage?resource_id=smily13&interface_id=thread>";
	if(n==14)
	smily="<img src=./interfaceenginev2.ResourceImage?resource_id=smily14&interface_id=thread>";
	if(n==15)
	smily="<img src=./interfaceenginev2.ResourceImage?resource_id=smily15&interface_id=thread>";
	if(n==16)
	smily="<img src=./interfaceenginev2.ResourceImage?resource_id=smily16&interface_id=thread>";
	if(n==17)
	smily="<img src=./interfaceenginev2.ResourceImage?resource_id=smily17&interface_id=thread>";
	if(n==18)
	smily="<img src=./interfaceenginev2.ResourceImage?resource_id=smily18&interface_id=thread>";
	if(n==19)
	smily="<img src=./interfaceenginev2.ResourceImage?resource_id=smily19&interface_id=thread>";
	if(n==20)
	smily="<img src=./interfaceenginev2.ResourceImage?resource_id=smily20&interface_id=thread>";
	
	return smily;
}

function addHtmlforSmily(message){
	var re1=new RegExp(':\\?:','g');
	message=message.replace(re1,"&lt;IMG src='../images/forumimages/smily/smily1.gif' &gt;");
	var re2=new RegExp(':x','g');
	message=message.replace(re2,"&lt;IMG src='../images/forumimages/smily/smily2.gif' &gt;");
	var re3=new RegExp(':\\?','g');
	message=message.replace(re3,"&lt;IMG src='../images/forumimages/smily/smily3.gif' &gt;");
	var re4=new RegExp(':roll:','g');
	message=message.replace(re4,"&lt;IMG src='../images/forumimages/smily/smily4.gif' &gt;");
	var re5=new RegExp(':D','g');
	message=message.replace(re5,"&lt;IMG src='../images/forumimages/smily/smily5.gif' &gt;");
	var re6=new RegExp(':evil:','g');
	message=message.replace(re6,"&lt;IMG src='../images/forumimages/smily/smily6.gif' &gt;");
	var re7=new RegExp(':shock:','g');
	message=message.replace(re7,"&lt;IMG src='../images/forumimages/smily/smily7.gif' &gt;");
	var re8=new RegExp(':\\)','g');
	message=message.replace(re8,"&lt;IMG src='../images/forumimages/smily/smily8.gif' &gt;");
	var re9=new RegExp(':-o','g');
	message=message.replace(re9,"&lt;IMG src='../images/forumimages/smily/smily9.gif' &gt;");
	var re10=new RegExp(':oops:','g');
	message=message.replace(re10,"&lt;IMG src='../images/forumimages/smily/smily10.gif' &gt;");
	var re11=new RegExp(':P','g');
	message=message.replace(re11,"&lt;IMG src='../images/forumimages/smily/smily11.gif' &gt;");
	var re12=new RegExp(':wink:','g');
	message=message.replace(re12,"&lt;IMG src='../images/forumimages/smily/smily12.gif' &gt;");
	var re13=new RegExp(':idea:','g');
	message=message.replace(re13,"&lt;IMG src='../images/forumimages/smily/smily13.gif' &gt;");
	var re14=new RegExp(':twisted:','g');
	message=message.replace(re14,"&lt;IMG src='../images/forumimages/smily/smily14.gif' &gt;");
	var re15=new RegExp(':!:','g');
	message=message.replace(re15,"&lt;IMG src='../images/forumimages/smily/smily15.gif' &gt;");
	var re16=new RegExp(':lol:','g');
	message=message.replace(re16,"&lt;IMG src='../images/forumimages/smily/smily16.gif' &gt;");
	var re17=new RegExp(':\\(','g');
	message=message.replace(re17,"&lt;IMG src='../images/forumimages/smily/smily17.gif' &gt;");
	var re18=new RegExp('8\\)','g');
	message=message.replace(re18,"&lt;IMG src='../images/forumimages/smily/smily18.gif' &gt;");
	var re19=new RegExp(':cry:','g');
	message=message.replace(re19,"&lt;IMG src='../images/forumimages/smily/smily19.gif' &gt;");
	var re20=new RegExp(':arrow:','g');
	message=message.replace(re20,"&lt;IMG src='../images/forumimages/smily/smily20.gif' &gt;");
	return message;
}
 function addHtml(message){
	var re1=new RegExp('<','g');
	var re2=new RegExp('>','g');
	message=message.replace(re1,"&lt;");
	message=message.replace(re2,"&gt;");
	return message;
}

 function click_submit(){
 	topic_name=getValue("replysubject");
 	message=getValue("bodytextarea");
	var text_color = getValue('textcolordropdown');
	var font_size = getValue('fontdropdown');
	message="<font color=\""+text_color+"\" size=\""+font_size+"\">"+message+"</font>";

	ForumUtil.submitReply(message,topic_name, 
								function(){ForumUtil.destroyAttachment(
										function(){location.href="./interfaceenginev2.PortalServlet?IID=forum";}
										                              )
						                  }
		                  );
	
}


 function storeCaret(textEl) {
	if (textEl.createTextRange) textEl.caretPos = document.selection.createRange().duplicate();
	}
	clientPC = navigator.userAgent.toLowerCase(); 
	var clientVer = parseInt(navigator.appVersion);
	var is_ie = ((clientPC.indexOf("msie") != -1) && (clientPC.indexOf("opera") == -1));
	var is_nav  = ((clientPC.indexOf('mozilla')!=-1) && (clientPC.indexOf('spoofer')==-1)
	              && (clientPC.indexOf('compatible') == -1) && (clientPC.indexOf('opera')==-1)
	              && (clientPC.indexOf('webtv')==-1) && (clientPC.indexOf('hotjava')==-1));
	var is_win   = ((clientPC.indexOf("win")!=-1) || (clientPC.indexOf("16bit") != -1));
	var is_mac    = (clientPC.indexOf("mac")!=-1);
	b_help = "Bold Text: [b]Text[/b]  (alt+b)";
	i_help = "Italic Text: [i]Text[/i]  (alt+i)";
	u_help = "Underline Text: [u]Text[/u]  (alt+u)";
	q_help = "Quote: [q]Text[/q]  (alt+q)";
	c_help = "Code: [code]Code[/code]  (alt+c)";
	l_help = "List: [list]Text[/list] (alt+l)";
	m_help = "Image: [img src]Text[/img src] (alt+m)";
	r_help = "Url: [a href]Text[/a] (alt+r)";
	a_help = "Close all bbcode marks";
	s_help = "Color: [color=red]Text[/color]  Tip: can also use color=#FF0000";
	f_help = "Font: [size=x-small]Small Text[/size]";
	bbcode = new Array();
	bbtags = new Array('<b>','</b>','<i>','</i>','<u>','</u>','<q>','</q>','<code>','</code>','<list>','</list>','<img src>','</img src>','<url>','</url>');
	imageTag = false;
	function helpline(help) {
	document.ForumReplyform.helpLine.value = eval(help + "_help");
}

 function getarraysize(thearray) {
	for (i = 0; i < thearray.length; i++) {
	if ((thearray[i] == "undefined") || (thearray[i] == "") || (thearray[i] == null))
	return i;
	}
	return thearray.length;
}

 function arraypush(thearray,value) {
	thearray[ getarraysize(thearray) ] = value;
}

 function arraypop(thearray) {
	thearraysize = getarraysize(thearray);
	retval = thearray[thearraysize - 1];
	delete thearray[thearraysize - 1];
	return retval;
}

 function fontstyle(bbopen, bbclose) {
	if ((clientVer >= 4) && is_ie && is_win) {
	theSelection = document.selection.createRange().text;
	var message = getValue('bodytextarea');
	
	if (!theSelection) {
		setValue('bodytextarea',message + bbopen + bbclose);
		document.getElementById('bodytextarea').focus();
	return;
	}
	document.selection.createRange().text = bbopen + theSelection + bbclose;
	document.getElementById('bodytextarea').focus();
	return;
	} else {
		setValue('bodytextarea',message + bbopen + bbclose);
		document.getElementById('bodytextarea').focus();
	return;
	}
	storeCaret(document.getElementById('bodytextarea'));
}

 function set_style(bbnumber) {
	donotinsert = false;
 	theSelection = false;
	bblast = 0;
	
// 	alert(bbnumber);
	
	if (bbnumber == -1) {
	while (bbcode[0]) {
	butnumber = arraypop(bbcode) - 1;
	setValue('bodytextarea',getValue('bodytextarea') + bbtags[butnumber + 1]);
	buttext = getValue('addstyle' + butnumber);
	setValue('addstyle' + butnumber, buttext.substr(0,(buttext.length - 1)) );
	}
	imageTag = false; 
	document.getElementById('bodytextarea').focus();
	return;
	}
	if ((clientVer >= 4) && is_ie && is_win)
	theSelection = document.selection.createRange().text; 
	if (theSelection) {
	document.selection.createRange().text = bbtags[bbnumber] + theSelection + bbtags[bbnumber+1];
	document.getElementById('bodytextarea').focus();
	theSelection = '';
	return;
	}
	for (i = 0; i < bbcode.length; i++) {
	if (bbcode[i] == bbnumber+1) {
	bblast = i;
	donotinsert = true;
	}
	}
	if (donotinsert) {
		
	while (bbcode[bblast]) {        
		
	butnumber = arraypop(bbcode) - 1;
	setValue('bodytextarea',getValue('bodytextarea') + bbtags[butnumber + 1]);
	buttext = getValue('addstyle' + butnumber);
	
	setValue('addstyle' + butnumber, buttext.substr(0,(buttext.length - 1)) );
	}
	document.getElementById('bodytextarea').focus();
	return;
	} else {
		 
		setValue('bodytextarea',getValue('bodytextarea') + bbtags[bbnumber]);
		arraypush(bbcode,bbnumber+1);
		eval(setValue('addstyle'+bbnumber,getValue('addstyle'+bbnumber) + "*"));
		document.getElementById('bodytextarea').focus();
		return;
	}
	storeCaret(document.getElementById('bodytextarea'));
	}
	
	function color_onchange(){
	var color=getValue('select_color');
	fontstyle('<font color='+color+'>','</color>');
	}
 	function size_onchange(){
		var size=getValue('select_size');
		fontstyle('<font size='+size+'>','</size>');
}

function click_cancel()
{
	ForumUtil.destroyAttachment(
		function(){location.href="./interfaceenginev2.PortalServlet?IID=forum";}
	);
}

function AttachFiles() {
	CallInterface("ForumAttachment")
}


function disablesmily_onclick()
{
	var disable_smily_check = getValue('checkbox2');
	if(disable_smily_check==true)
	{
		document.getElementById('smilybox').style.visibility='hidden';
		stripImage(document.getElementById('bodytextarea'));		
 				
	}
	else
	{
		document.getElementById('smilybox').style.visibility='visible';
	}
}
		
		
function disablehtml_onclick()
{
	var disable_smily_check = getValue('checkbox1');
// 			alert(disable_smily_check);
	if(disable_smily_check==true)
	{
// 				alert('1111111');
		document.getElementById('smilybox').style.visibility='hidden';
		document.getElementById('replybuttonbar').style.visibility='hidden';
		document.getElementById('textcolor').style.visibility='hidden';
		document.getElementById('textcolordropdown').style.visibility='hidden';
		document.getElementById('font').style.visibility='hidden';
		document.getElementById('fontdropdown').style.visibility='hidden';
		var message_text=document.getElementById('bodytextarea').value;
		stripHTML(document.getElementById('bodytextarea'));
 				
	}
	else
	{
// 				alert('2222222');
		// 
		document.getElementById('smilybox').style.visibility='visible';				
		document.getElementById('replybuttonbar').style.visibility='visible';
		document.getElementById('textcolor').style.visibility='visible';
		document.getElementById('textcolordropdown').style.visibility='visible';
		document.getElementById('font').style.visibility='visible';
		document.getElementById('fontdropdown').style.visibility='visible';
	}
}
		
		
		
function stripHTML(){
	var re = /(<([^>]+)>)/gi;
	for (i=0; i < arguments.length; i++)
	arguments[i].value=arguments[i].value.replace(re, "")
}

function stripImage(){
	var re = /(<img([^>]+)>)/gi;
	for (i=0; i < arguments.length; i++)
	arguments[i].value=arguments[i].value.replace(re, "")
}



function color_onchange()
{
	var text_color=getValue('textcolordropdown');
			
	document.getElementById('bodytextarea').style.color=""+text_color+"";
}
		
function font_onchange()
		{
		}



