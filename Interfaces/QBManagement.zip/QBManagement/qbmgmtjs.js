
function upload_onclick()
{
	var qbid=getSelectedRow('QBManagementGrid','qb_id');
	var file = getValue('BrowseFile');
	if(qbid){
		
		StAsmtAdmin.UploadFile(qbid,file,function(data) {
			setValue('message',data);
		});
	}
	else{
		alert("Please Select a Row");
	}
}

function download_onclick()
{
	var qbid=getSelectedRow('QBManagementGrid','qb_id');
	var file = getValue('BrowseFile');
	if(qbid){
		
		StAsmtAdmin.DownloadFile(qbid,function(data) {
			window.open(data);
		});
	}
	else{
		alert("Please Select a Row");
	}
}
