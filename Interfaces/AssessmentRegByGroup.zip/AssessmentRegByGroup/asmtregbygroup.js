function unreggroupfnc(data) {
	setValue('message',data);
	setReloadGrid('AssessmentRegByGroupGrid');
}

function unregisteredAllGroups_onclick(){

	var assessmentid=getValue('assessment_id');
	var send_mail="";
	if(assessmentid!=0){
		StAsmtAdmin.deleteAllAssessmentGroupRegistration(assessmentid,send_mail,unreggroupfnc);
	}
	else{
		alert("Pleare Select an Assessment");
	}		
}

function uploadfnc(data) {
	setValue('message',data);
	setReloadGrid('AssessmentRegByGroupGrid');
}

function upload_onclick(){
	var assessmentid=getValue('assessment_id');
	var file = getValue('BrowseFile');
	
	if(assessmentid!=0){
		StAsmtAdmin.BulkGroupRegistration(assessmentid,file,uploadfnc);
	}
	else{
		alert("Pleare Select an Assessment");
	}
}
