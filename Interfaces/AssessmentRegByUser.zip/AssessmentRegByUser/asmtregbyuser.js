function unregfunc(data) {
	setValue('message',data);
	fadeOut('message');
	setReloadGrid('AssessmentRegByUserGrid');
}

function unregisteredAllUsers_onclick(){
	setValue('message',"");
	$("#message").fadeIn();
	var assessmentid=getValue('assessment_id');
	var send_mail="";
	if(assessmentid!=0){
		
		StAsmtAdmin.deleteAllAssessmentUserRegistration(assessmentid,send_mail,unregfunc);
		
	}
	else{
		alert("Pleare Select an Assessment");
	}		
}


function upload_onclick(){
	var assessmentid=getValue('assessment_id');
	if(assessmentid!=0){
		var file2=document.getElementById("BrowseFile").value;
		TestFileType(file2, ['ab','xls']);
	
	}
	else{
		alert("Pleare Select an Assessment");
	}
}

function bulkuploadfunc(data) {
	setValue('message',data);
	$("#message").fadeOut("slow");
	setReloadGrid('AssessmentRegByUserGrid');
}

function TestFileType(fileName, fileTypes) {
	var assessmentid=getValue('assessment_id');
	var file = getValue('BrowseFile');
	
	if (!fileName) 
	alert("Please select a file");
	else{
		dots = fileName.split(".");
		fileType = "." + dots[dots.length-1];
		if(fileTypes.join(".").indexOf(fileType) != -1)
		{
			setValue('message',"");
			fadeIn('message');
			StAsmtAdmin.BulkUserRegistration(assessmentid,file,bulkuploadfunc);
			
		}
		else{
			alert("Not valid file type");	
		}
	}	
	
}


function timefunc(value)
{
	dots = value.split(":");
	if (dots.length <3 || value=="") 
	{
		return [false,"Illegal time value, please enter correct time."];		
	}	
	else
	{
		for(i=0;i<dots.length;i++)
		{
			var size=dots[i].length;
			if (size!=2) 
			{
				return [false,"Illegal time value, please enter correct time."];
			}
			else{
				if(isInteger(dots[i]) || (i==0 && dots[i]>24) || (i==1 && dots[i]>59) || (i==2 && dots[i]>59))
				{	
					return [false,"Illegal time value, please enter correct time."];
				}
			}			
		}
		return [true,""];	
	}
}

function isInteger(numval)
{
	var intarray=[0,1,2,3,4,5,6,7,8,9];
	var num1 = numval.charAt(0);
	var num2 = numval.charAt(1);		
	if((intarray.indexOf(num1) != -1) && (intarray.indexOf(num2) != -1))
			return true;
	else
			return false;	
}